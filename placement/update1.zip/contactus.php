<?php include("header.php"); ?>
<div class="wrap">
	<div class="grid-container">
		<div class="grid-80">
			<div class="grid-block">
				<div class="index-intro-text">
					<h1>Contact Us</h1>
	<p>Students Training and Placement Cell is responsible for facilitating all types of training and placement related activities in the institute.
</p>
<h2>Professor In-charge</h2><hr />
<table style="width:100%;">
<tr><td style="width:50%;">
<img src="images/fac/5.jpg"><br>
<b>Dr. Sumanta Gupta</b><br />
Professor In-charge<br />
Phone No: +91-612-3028096 (O)<br />
<!-- Mobile   : +91-9470062488<br /> -->
Email    : sumanta@iitp.ac.in<br />
</td>
<td style="width:50%;">
<img src="images/fac/2.jpg"><br>
<b>Dr. Akhilendra Singh<br />
</b>Team Member<br />
  Phone No.: +91-612-3028018<br />
<!--  Mobile No.: +91-9631221406<br />	-->
  Email: akhil@iitp.ac.in</td><br /></tr>

<tr><td style="width:50%;">
<img src="images/fac/3.jpg" width="72" height="80"><br>
<b>Dr. Jimson Mathew</b><br />
Team Member<br />
Phone No: +91-612-3028347 (O)<br />
<!-- Mobile   : +91-9470062488<br /> -->
Email    : jimson@iitp.ac.in<br />
</td>
<td style="width:50%;">
<img src="images/fac/4.jpg"><br>
<b>Dr. Amarnath Hegde</b><br />
 </b>Team Member</b><br />
  Phone No.: +91-612-3028031<br />
<!--  Mobile No.: +91-9631221406<br />	-->
  Email: ahegde@iitp.ac.in</td></tr>

<tr><td style="width:50%;">
<img style="width=72px;height=72px;" src="images/fac/7.jpg"><br>
<b>Dr. Richa Chaudhary</b><br />
Team Member<br />
<!-- Mobile   : +91-9470062488<br /> -->
Email    : richa.chaudhary@iitp.ac.in<br />
</td></tr>

</table>
  <hr />
<p><b>Address</b><br />
  Training and Placement Cell,<br />
  IIT Patna, Bihta Campus,<br />
  Bihta Kanpa Road, Bihta,<br />
  Bihar Pin - 801118, India.<br />
</p>
 <hr />
<p>
<b>Office Assistant</b><br />
Mr. Arvind Prakash<br />
Phone No.: +91-612-3028083<br>
Email:
<a href="mailto:tpc@iitp.ac.in">tpc@iitp.ac.in</a></br>
</p>

<h2>Student Representatives</h2><hr />

<b>Head Coordinator</b><br />
<table style="width:100%;">

<tr>
<td style="width:33%;"><p>
Amar Parulekar<br>
<a href="mailto:amar.ee12@iitp.ac.in">amar.ee12@iitp.ac.in</a></br>
+91-8084339336
</p></td>

<tr>
</table>

<b>B.Tech. Coordinators 4th Year</b><br />
<br>
<b>Computer Science Engineering</b><br />
<table style="width:100%;">
<tr>
</br>
<td style="width:33%;">

<img class="coordimage" src="images/coord/1.jpg">
<div class="coordinfo">
<p>Sumit Asthana<br>
<a href="mailto:sumit.cs13@iitp.ac.in">sumit.cs13@iitp.ac.in</a></br>
+91-8292316576
</p>
</div>
</img>
</td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/2.jpg">
	<div class="coordinfo">
<p>
Arindam Banerjee<br>
<a href="mailto:arindam.cs13@iitp.ac.in">arindam.cs13@iitp.ac.in</a></br>
+91-9472472543
</p>
</td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/3.jpg">
<div class="coordinfo">
<p>
Shubham Verma<br>
<a href="mailto:shubham.ee13@iitp.ac.in">shubham.ee13@iitp.ac.in</a></br>
+91-7762882652
</p>
</td>

</tr></table>
<b>Electrical Engineering</b><br />
<table style="width:100%;">

<tr>

	</br>
<td style="width:33%;">
	<img class="coordimage" src="images/coord/4.jpg">
<div class="coordinfo">
	<p>
Ganesh Mulay<br>
<a href="mailto:mulay.ee13@iitp.ac.in">mulay.ee13@iitp.ac.in</a></br>
+91-7783805949
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/5.jpg">
	<div class="coordinfo">
		<p>
Sukhpreet Singh Virk<br>
<a href="mailto:sukhpreet.ee13@iitp.ac.in">sukhpreet.ee13@iitp.ac.in</a></br>
+91-9465355470
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/6.jpg">
	<div class="coordinfo">
		<p>
Srikanth Mv.<br>
<a href="mailto:mantravadi.ee13@iitp.ac.in">mantravadi.ee13@iitp.ac.in</a></br>
+91-9472472477
</p></td>

<tr>
</table>

</br>
  <b>Mechanical Enigineering</b><br />
  <table style="width:100%;">
<tr>

	</br>
<td style="width:33%;">
	<img class="coordimage" src="images/coord/0.jpg">
	<div class="coordinfo">
		<p>
Ram Agrawal<br>
<a href="mailto:ram.me13@iitp.ac.in">ram.me13@iitp.ac.in</a></br>
+91-9472472455
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/8.jpg">
	<div class="coordinfo">
		<p>
Alok Kumar<br>
<a href="mailto:alok.me13@iitp.ac.in">alok.me13@iitp.ac.in</a></br>
+91-9709348974
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/0.jpg">
	<div class="coordinfo">
		<p>
Nitesh Kumar<br>
<a href="mailto:nitesh.me13@iitp.ac.in">nitesh.me13@iitp.ac.in</a></br>
+91-8804254160
</p></td>
</tr></table>

<b>Civil and Infrastructure Engineering</b><br />
<table style="width:100%;">
<tr>

	</br>
<td style="width:33%;">
	<img class="coordimage" src="images/coord/0.jpg">
	<div class="coordinfo">
		<p>
J. Ajay Reddy<br>
<a href="mailto:juturu.ce13@iitp.ac.in">juturu.ce13@iitp.ac.in</a></br>
+91-9472472198
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/11.jpg">
	<div class="coordinfo">
		<p>
Gaurav Garg<br>
<a href="mailto:gaurav.ce13@iitp.ac.in">gaurav.ce13@iitp.ac.in</a></br>
+91-9709804928
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/0.jpg">
	<div class="coordinfo">
		<p>
Nilesh Kumar Singh<br>
<a href="mailto:nilesh.ce13@iitp.ac.in">nilesh.ce13@iitp.ac.in</a></br>
+91-7549202640
</p></td>
</tr></table>

<b>Chemical Science and Technology</b><br />
<table style="width:100%;">
<tr>

	</br>
<td style="width:33%;">
	<img class="coordimage" src="images/coord/13.jpg">
	<div class="coordinfo">
		<p>
Arpit Goyal<br>
<a href="mailto:ram.me13@iitp.ac.in">arpit.ch13@iitp.ac.in</a></br>
+91-7779892749
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/14.jpg">
	<div class="coordinfo">
		<p>
Ashutosh Singh<br>
<a href="mailto:ashutosh.ch13@iitp.ac.in">ashutosh.ch13@iitp.ac.in</a></br>
+91-8292338658
</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/15.jpg">
	<div class="coordinfo">
		<p>
Brij Saxena<br>
<a href="mailto:brijsaxena.ch13@iitp.ac.in">brijsaxena.ch13@iitp.ac.in</a></br>
+91-8292339926
</p></td>
</tr></table>

</br>
<b>B.Tech. Coordinators 3rd Year</b><br />
<br>
<b>Computer Science Engineering</b><br />
<table style="width:100%;">
<tr>
</br>
<td style="width:33%;">

<img class="coordimage" src="images/coord/16.jpg">
<div class="coordinfo">
<p>Anupam Das<br>
<a href="mailto:anupam.ee14@iitp.ac.in">anupam.ee14@iitp.ac.in</a></br>
+91-9709313113
</p>
</div>
</img>
</td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/17.jpg">
	<div class="coordinfo">
<p>
Chirag Soni<br>
<a href="mailto:chirag.cs14@iitp.ac.in">chirag.cs14@iitp.ac.in</a></br>
+91-9709320724
</p>
</td>

</tr></table>

</br>
  <b>Mechanical Enigineering</b><br />
  <table style="width:100%;">
<tr>

	</br>
<td style="width:33%;">
	<img class="coordimage" src="images/coord/22.jpg">
	<div class="coordinfo">
		<p>Jatin Kalra<br>
<a href="mailto:jatin.me14@iitp.ac.in">jatin.me14@iitp.ac.in</a></br>
+91-9812700181
</p></td>

</tr></table>

<b>Civil and Infrastructure Engineering</b><br />
<table style="width:100%;">
<tr>

	</br>

	<td style="width:33%;">
		<img class="coordimage" src="images/coord/25.jpg">
		<div class="coordinfo">
			<p>Akshay Patni<br>
	<a href="mailto:gaurav.ce13@iitp.ac.in">akshay.ce14@iitp.ac.in</a></br>
	+91-9631088382
	</p></td>

<td style="width:33%;">
	<img class="coordimage" src="images/coord/26.jpg">
	<div class="coordinfo">
		<p>Amit Pratap Singh<br>
<a href="mailto:amit.ce14@iitp.ac.in">amit.ce14@iitp.ac.in</a></br>
+91-9006743061
</p></td>

</tr></table>
</br>
<b>M.Tech. Coordinators</b><br />

</p>
<b>Computer Science</b><br />
<p>
Subrata Das<br>
<a href="mailto:subrata.mtcs14@iitp.ac.in">subrata.mtcs14@iitp.ac.in</a></br>
9006702871
</p>
<b>Communication System Engineering</b><br />
<p>
	Chandan Kumar Singh<br>
	<a href="mailto:chandan.mtcm14@iitp.ac.in">chandan.mtcm14@iitp.ac.in</a></br>
	8651476370
</p>
<b>Mechanical Engineering</b><br />
<p>
	Sanket A. Bhole<br>
	<a href="mailto:bhole.mtcm14@iitp.ac.in">bhole.mtcm14@iitp.ac.in</a></br>
	9004035910
</p>
<b>Material Sc. & Engineering</b><br />
<p>
	Mohd. Sharib<br>
	<a href="mailto:mohd.mtcm14@iitp.ac.in">mohd.mtcm14@iitp.ac.in</a></br>
	8541881894/9412103396
</p>
<b>Nanoscience and Technology</b><br />
<p>
	Puchakatla Venkata Subbaiah<br>
	<a href="mailto:puchakatla.mtnt14@iitp.ac.in">puchakatla.mtnt14@iitp.ac.in</a></br>
	9122743623
</p>
<b>Mechatronics</b><br />
<p>
	Vivek Singh<br>
	<a href="mailto:vivek.mtmt14@iitp.ac.in">vivek.mtmt14@iitp.ac.in</a></br>
	9709310435
</p>
<b>Mathematics and Computing</b><br />
<p>
	Danish Ali P<br>
	<a href="mailto:danish.mtmc14@iitp.ac.in">danish.mtmc14@iitp.ac.in</a></br>
	9006743358
</p>
<b>Civil & Infrastructural</b><br />
<p>
	Pranjul Pandey<br>
	<a href="mailto:pranjul.mtce14@iitp.ac.in">pranjul.mtce14@iitp.ac.in</a></br>
	7050210579
</p>
<table style="width:100%;">

</table>

				</div>
			</div>
		</div>
		<div class="grid-20">
			<?php include("panel.php"); ?>
		</div>
	</div>
</div>
<style type="text/css">
.coordimage {
    border-radius:10%;
    border: 1px solid #000;
    overflow:hidden;
    width: 78px;
    height: 73px;
	}
</style>
<?php include("footer.php"); ?>
